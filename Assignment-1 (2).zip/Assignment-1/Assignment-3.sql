--1. Create a stored procedure to display the restaurant name, type and cuisine where the
--table booking is not zero.

CREATE PROCEDURE GetRestaurantsWithTableBooking
AS
BEGIN
    SELECT
        RestaurantName,
        RestaurantType,
        CuisinesType
    FROM Restaurant
    WHERE TableBooking <> 'No';
END;

EXEC GetRestaurantsWithTableBooking;

--2. Create a transaction and update the cuisine type ‘Cafe’ to ‘Cafeteria’. Check the result
--and rollback it.
UPDATE Restaurant
SET CuisinesType = 'Cafeteria'
WHERE CuisinesType = 'Cafe';

-- Check the updated records
SELECT *
FROM Restaurant
WHERE CuisinesType = 'Cafeteria';

-- Undo the update
ROLLBACK TRANSACTION;

-- Check the original records
SELECT *
FROM Restaurant
WHERE CuisinesType = 'Cafe';


--3. Generate a row number column and find the top 5 areas with the highest rating of
--restaurants.

WITH RestaurantRanking AS
(
    SELECT
        ROW_NUMBER() OVER (ORDER BY Rating DESC) AS RowNum,
        RestaurantName,
        Area,
        Rating
    FROM Restaurant
)
SELECT *
FROM RestaurantRanking
WHERE RowNum <= 5;


--4. Use the while loop to display the 1 to 50.

DECLARE @i INT = 1;

WHILE @i <= 50
BEGIN
    PRINT @i;

    SET @i = @i + 1;
END;


--5. Write a query to Create a Top rating view to store the generated top 5 highest rating of
--restaurants.

CREATE VIEW TopRating
AS
SELECT TOP 5
    RestaurantName,
    RestaurantType,
    Rating,
    Area,
    CuisinesType
FROM Restaurant
ORDER BY Rating DESC;

SELECT * FROM TopRating

--6. Create a trigger that give an message whenever a new record is inserted

CREATE TRIGGER trg_Restaurant_Insert
ON Restaurant
AFTER INSERT
AS
BEGIN
    PRINT 'New restaurant record inserted successfully!';
END;
