

1) Insert into Orders (OrderId, CustomerId, SalesmanId,OrderDate,Amount)
   Values (7001, 3001, 5001, '2025-01-15',1200.00);   

2) I)ALTER TABLE Salesman ADD CONSTRAINT PK_Salesman 
                    PRIMARY KEY (SalesmanId);

   II)ALTER TABLE Salesman  ADD CONSTRAINT DF_Salesman_City
                    DEFAULT ('DefaultCity') FOR City;

   III)ALTER TABLE Customer WITH NOCHECK ADD CONSTRAINT FK_Customer_Salesman
                     FOREIGN KEY (SalesmanId) REFERENCES Salesman (SalesmanId);

   IV)ALTER TABLE Customer ALTER COLUMN Customer_name 
                   VARCHAR(255) NOT NULL;


3) SELECT   C.Customer_name,O.PurchaseAmount  FROM Customer AS C
   INNER JOIN Orders AS ON C.CustomerId = O.CustomerId WHERE C.Customer_name 
   LIKE '%N' AND O.PurchaseAmount > 500;

4) I) SELECT SalesmanId
      FROM Salesman
      UNION
      SELECT SalesmanId
      FROM Orders;

  II) SELECT SalesmanId
      FROM Salesman
      UNION ALL
      SELECT SalesmanId
      FROM Orders;

5) SELECT
    O.Orderdate,
    S.Name AS SalesmanName,
    C.CustomerName,
    S.Commission,
    S.City
   FROM Orders O
   INNER JOIN Salesman S
    ON O.SalesmanId = S.SalesmanId
   INNER JOIN Customer C
    ON O.CustomerId = C.CustomerId
    AND O.SalesmanId = C.SalesmanId
   WHERE C.PurchaseAmount BETWEEN 500 AND 1500;


6) SELECT
    S.SalesmanId,
    S.Name AS SalesmanName,
    S.Commission,
    S.City,
    S.Age,
    O.OrderId,
    O.CustomerId,
    O.SalesmanId AS OrderSalesmanId,
    O.Orderdate,
    O.Amount
   FROM Salesman S
   RIGHT JOIN Orders O
    ON S.SalesmanId = O.SalesmanId;




  
