--1) Create a user-defined functions to stuff the Chicken into ‘Quick Bites’. Eg: ‘Quick
--Chicken Bites’. 

CREATE FUNCTION dbo.fn_InsertChicken
     (
       @RestaurantType VARCHAR(100)
     )
     RETURNS VARCHAR(200)
     AS
    BEGIN
     RETURN STUFF(@RestaurantType, 7, 0, ' Chicken');
    END;

--2) Use the function to display the restaurant name and cuisine type which has the
--maximum number of rating.

SELECT
    RestaurantName,
    Cuisine,
    Rating,
    dbo.fn_InsertChicken('Quick Bites') AS ModifiedName
   FROM Jomato
   WHERE Rating = (
    SELECT MAX(Rating)
    FROM Jomato
   );

--3) Create a Rating Status column to display the rating as ‘Excellent’ if it has more the 4
--start rating, ‘Good’ if it has above 3.5 and below 5 star rating, ‘Average’ if it is above 3
--and below 3.5 and ‘Bad’ if it is below 3 star rating.
  
SELECT
    RestaurantName,
    Rating,
    CASE
        WHEN Rating > 4 THEN 'Excellent'
        WHEN Rating > 3.5 AND Rating < 5 THEN 'Good'
        WHEN Rating > 3 AND Rating < 3.5 THEN 'Average'
        WHEN Rating < 3 THEN 'Bad'
        ELSE 'Unclassified'
    END AS RatingStatus
    FROM Jomato;

--4) Find the Ceil, floor and absolute values of the rating column and display the current date
--and separately display the year, month_name and day. 

SELECT
    Rating,
    CEILING(Rating) AS CeilingRating,
    FLOOR(Rating) AS FloorRating,
    ABS(Rating) AS AbsoluteRating
   FROM Jomato;

   SELECT GETDATE() AS CurrentDate;

   SELECT
    YEAR(GETDATE()) AS CurrentYear,
    DATENAME(MONTH, GETDATE()) AS MonthName,
    DAY(GETDATE()) AS DayNumber;

--5) Display the restaurant type and total average cost using rollup

SELECT
    RestaurantType,
    AVG(AverageCost) AS TotalAverageCost
   FROM Jomato
   GROUP BY ROLLUP(RestaurantType);