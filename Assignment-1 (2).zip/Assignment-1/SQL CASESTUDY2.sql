--Simple Queries:
--1. List all the employee details.
select * from employee

--2. List all the department details.
select * from DEPARTMENT

--3. List all job details.
select * from job

--4. List all the locations.
select * from LOCATION

--5. List out the First Name, Last Name, Salary, Commission for all Employees
select first_name,last_name,salary,comm from employee

--6.List out the Employee ID, Last Name, Department ID for all employees and alias
select employee_id as 'ID of the Employee', last_name as 'Name of the
Employee', department_id as Dep_id from employee

--7.List out the annual salary of the employees with their names only
select First_name,salary from employee

select * from job
select * from DEPARTMENT
select * from employee
select * from LOCATION


--WHERE Condition
--1.List the details about "Smith"
select * from employee where last_name='smith'

--2.List out the employees who are working in department 20.
select * from employee where department_id=20

--3.List out the employees who are earning salary between 2000 and 3000
select first_name,salary from employee where salary between 2000 and 3000

--4.List out the employees who are working in department 10 or 20
select first_name from employee where department_id=10 or department_id=20

--5.Find out the employees who are not working in department 10 or 30.
select * from employee where not department_id=10 and not department_id=30

--6.List out the employees whose name starts with 'L'.
select first_name from employee where first_name like 'L%'

--7.List out the employees whose name starts with 'L' and ends with 'E'.
select first_name from employee where first_name like 'L%' and FIRST_NAME LIKE '%E'

--8.List out the employees whose name length is 4 and start with 'J'.
Select * from employee where len(first_name)=4 and first_name like 'j%'

--9.List out the employees who are working in department 30 and draw the salaries more than 2500.
select * from employee where department_id=30 and salary >2500

--10.List out the employees who are not receiving commission
select * from employee where comm is null

--ORDER BY Clause:
--1.List out the Employee ID and Last Name in ascending order based on the Employee ID.
select employee_id,last_name from employee order by employee_id asc

--2.List out the Employee ID and Name in descending order based on salary
select employee_id,first_name from employee order by salary desc

--3.List out the employee details according to their Last Name in ascending-order.
select * from employee order by last_name asc

--4.List out the employee details according to their Last Name in ascending
-- order and then Department ID in descending order.
select * from employee order by last_name asc,department_id desc

--GROUP BY and HAVING Clause:

--1.How many employees are in different departments in the organization?
select department_id,count(employee_id) as employee_count from employee 
group by department_id order by department_id

--2.List out the department wise maximum salary, minimum salary and
--  average salary of the employees
select department_id,max(salary) as maxSal,min(salary) as minSal,avg(salary) as avgSal
from employee group by department_id 

--3. List out the job wise maximum salary, minimum salary and average
--  salary of the employees
select job_id,max(salary) as maxSal,min(salary) as minSal,avg(salary) as avgSal
from employee group by JOB_id

--4.List out the number of employees who joined each month in ascending order.
select month(hire_date) joinedmonth, count(employee_id) as noOfemp from employee
group by month(hire_date) order by joinedmonth asc

--5. List out the number of employees for each month and year in
--   ascending order based on the year and month
select month(hire_date) joinedmonth,year(hire_date) as joinedyear, count(employee_id) as noOfemp 
from employee group by month(hire_date),year(hire_date) order by joinedmonth,joinedyear asc

--6.List out the Department ID having at least four employees
select department_id from employee 
group by department_id having count(employee_id) >=4

--7.How many employees joined in january month.
select  month(hire_date) as joinedmonth,count(employee_id) as emp from employee 
group by month(hire_Date)
having month(hire_date) in (1)

--8. How many employees joined in january or september month.
select month(hire_date) as joinedmonth,count(employee_id) as numofemp from employee
group by month(hire_date) having month(hire_date) in (1,9)

--9.How many employees joined in 1985?
select year(hire_date) as joinedyear,count(employee_id) as emp from employee
group by year(hire_date)
having year(hire_date) in (1985)

--10.How many employees joined each month in 1985?
select year(hire_date) as joinedyear,month(hire_date) as joinedmonth,
count(employee_id) as noOfEmp from employee 
group by month(hire_date),year(hire_date)
having year(hire_date) in (1985)

--11.How many employees were joined in April 1985?
select month(hire_date) as joinedmonth,year(hire_date) as joinedyear,
count(employee_id) as noofemp from employee
group by month(hire_date),year(hire_date)
having month(hire_date) in (4) and year(hire_date) in (1985)

--12.Which is the Department ID having greater than or equal to 3 employees
--  joining in April 1985?
select department_id,count(employee_id) as noofemp from employee 
where month(hire_date)=4 and year(hire_date)=1985
group by department_id
having count(employee_id) >=3

--Joins:
--1.List employees with their department names.
select e.Employee_Id,e.First_Name,e.Last_Name,d.Name AS Department_Name
from employee e inner join department d
ON e.Department_Id = d.Department_Id;

--2.Display employees with their designations.
select e.Employee_Id,e.First_Name,e.Last_Name,j.Designation
from employee e inner join job j ON e.Job_Id = j.Job_ID;

--3.Display employees with department names and regional groups.
select e.Employee_Id,e.First_Name,e.Last_Name,d.Name AS Department_Name,l.City
from employee e inner join department d
    ON e.Department_Id = d.Department_Id
inner join location l
    ON d.Location_Id = l.Location_ID;

--4.How many employees are working in different departments? Display with department names.
SELECT
    d.Name AS Department_Name,
    COUNT(e.Employee_Id) AS Employee_Count
FROM DEPARTMENT d
LEFT JOIN EMPLOYEE e
    ON d.Department_Id = e.Department_Id
GROUP BY d.Department_Id, d.Name
ORDER BY d.Department_Id;

--5.How many employees are working in the Sales department?
SELECT
    d.Name AS Department_Name,
    COUNT(e.Employee_Id) AS Employee_Count
FROM DEPARTMENT d
INNER JOIN EMPLOYEE e
    ON d.Department_Id = e.Department_Id
WHERE d.Name = 'Sales'
GROUP BY d.Name;

--6.Which department has greater than or equal to 5 employees? Display department 
names in ascending order.
SELECT
    d.Name AS Department_Name,
    COUNT(e.Employee_Id) AS Employee_Count
FROM DEPARTMENT d
INNER JOIN EMPLOYEE e
    ON d.Department_Id = e.Department_Id
GROUP BY d.Department_Id, d.Name
HAVING COUNT(e.Employee_Id) >= 5
ORDER BY d.Name ASC;

--7.How many jobs are there in the organization? Display with designations.
SELECT
    j.Designation,
    COUNT(e.Employee_Id) AS Employee_Count
FROM JOB j
LEFT JOIN EMPLOYEE e
    ON j.Job_ID = e.Job_Id
GROUP BY j.Job_ID, j.Designation
ORDER BY j.Job_ID;

--8.How many employees are working in New York?
SELECT
    l.City,
    COUNT(e.Employee_Id) AS Employee_Count
FROM LOCATION l
INNER JOIN DEPARTMENT d
    ON l.Location_ID = d.Location_Id
INNER JOIN EMPLOYEE e
    ON d.Department_Id = e.Department_Id
WHERE l.City = 'New York'
GROUP BY l.City;

--9.Display employee details with salary grades. Use a conditional statement to 
create a grade column.
SELECT
    Employee_Id,
    First_Name,
    Last_Name,
    Salary,
    CASE
        WHEN Salary >= 2500 THEN 'A'
        WHEN Salary >= 1500 THEN 'B'
        ELSE 'C'
    END AS Salary_Grade
FROM EMPLOYEE;

--10.List the number of employees grade-wise. Use a conditional statement to create a grade column.
SELECT
    CASE
        WHEN Salary >= 2500 THEN 'A'
        WHEN Salary >= 1500 THEN 'B'
        ELSE 'C'
    END AS Salary_Grade,
    COUNT(Employee_Id) AS Employee_Count
FROM EMPLOYEE
GROUP BY
    CASE
        WHEN Salary >= 2500 THEN 'A'
        WHEN Salary >= 1500 THEN 'B'
        ELSE 'C'
    END
ORDER BY Salary_Grade;

--11.Display employee salary grades and number of employees between 2000 and 5000 salary range.
SELECT
    CASE
        WHEN Salary >= 2500 THEN 'A'
        WHEN Salary >= 1500 THEN 'B'
        ELSE 'C'
    END AS Salary_Grade,
    COUNT(Employee_Id) AS Employee_Count
FROM EMPLOYEE
WHERE Salary BETWEEN 2000 AND 5000
GROUP BY
    CASE
        WHEN Salary >= 2500 THEN 'A'
        WHEN Salary >= 1500 THEN 'B'
        ELSE 'C'
    END;

--12.Display all employees in Sales or Operations departments.
SELECT
    e.Employee_Id,
    e.First_Name,
    e.Last_Name,
    d.Name AS Department_Name
FROM EMPLOYEE e
INNER JOIN DEPARTMENT d
    ON e.Department_Id = d.Department_Id
WHERE d.Name IN ('Sales', 'Operations');



-- CONDITIONAL STATEMENT
--1.Display the employee details with salary grades. Use conditional statement to
--    create a grade column
select *,
CASE
when salary >=2000 then 'A'
when salary <=2000 and salary > 1000 then 'B'
else 'C'
end as salGrade
from employee

--2.List out the number of employees grade wise. Use conditional statement to
--   create a grade column
SELECT
    CASE
        WHEN salary >= 2000 THEN 'A'
        WHEN salary > 1000 THEN 'B'
        ELSE 'C'
    END AS salGrade,
    COUNT(*) AS noofemp
FROM employee
GROUP BY
    CASE
        WHEN salary >= 2000 THEN 'A'
        WHEN salary > 1000 THEN 'B'
        ELSE 'C'
    END;

--3.Display the employee salary grades and the number of employees between
--   2000 to 5000 range of salary

select count(*) as noofemp,
CASE
when salary >=2000 then 'A'
when salary <=2000 and salary > 1000 then 'B'
else 'C'
end as salGrade
from employee
where salary between 2000 and 5000
group by salary

--Subqueries:
--1.Display the employees list who got the maximum salary
select * from employee where salary=(select max(salary) from employee)

--2.Display the employees who are working in the sales department.
select * from employee where department_id =(select department_id from department where name='sales')

--3.Display the employees who are working as 'Clerk'.
select * from employee where job_id =(select job_id from job where designation='clerk')

--4.Display the list of employees who are living in 'New York'.
select * from employee where department_id in (SELECT DEPARTMENT_ID
FROM DEPARTMENT where location_id in (select location_id from location where city='New York'))

--5.Find out the number of employees working in the sales department
select count(employee_id) as noofemp from employee where department_id in (SELECT DEPARTMENT_ID
FROM DEPARTMENT where name = 'sales')

--6.Update the salaries of employees who are working as clerks on the basis of 10%.
update employee set salary = salary * 1.10
where job_id = (
    select job_id from job
    where designation = 'clerk'
);

--7.Display the second highest salary drawing employee details.
select * from
(select *,dense_rank() over(order by salary desc) dr from employee) employee
WHERE dr=2

--8.List out the employees who earn more than every employee in department 30.
select * from employee
where salary > all (
    select salary from employee
    where department_Id = 30
);

--9.Find out which department has no employees
select d.DEPARTMENT_ID,d.NAME from department D
where not exists
(select * from employee where DEPARTMENT_ID=D.DEPARTMENT_ID)

--10.Find out the employees who earn greater than the average salary for
-- their department.
select * from employee E
where salary > (
    select AVG(salary) from employee
    where department_id = E.department_id
);

--11. List employees who earn more than the lowest salary in their department.
select *
FROM EMPLOYEE e
WHERE Salary > (
    SELECT MIN(Salary)
    FROM EMPLOYEE
    WHERE Department_Id = e.Department_Id
);

--12. Find out which department has no employees.
select * from department d
where not exists (
    select 1 from employee e
    where e.Department_Id = d.Department_Id
);


--13.Find employees who earn greater than the average salary for their department.
select * from employee e
where salary > (
    select AVG(salary) from employee
    where department_Id = e.department_Id
);




















